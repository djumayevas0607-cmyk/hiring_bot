import os
import threading
from flask import Flask

# Запуск твоего бота в отдельном потоке
def run_bot():
    os.system("python bot.py")  # запускает bot.py как есть

threading.Thread(target=run_bot).start()

# Мини-вебсервер для Koyeb
app = Flask(__name__)

@app.route("/")
def index():
    return "Bot is alive!", 200

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    app.run(host="0.0.0.0", port=port)
